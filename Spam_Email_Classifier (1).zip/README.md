# Spam Email Classifier

This project is a basic machine learning model to classify emails as spam or not spam.

## Requirements
- Python 3.x
- scikit-learn
- pandas

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the model: `python spam_classifier.py`

## Dataset
You can use datasets like the [Enron Spam Dataset](https://www.kaggle.com/wcukierski/enron-email-dataset).
